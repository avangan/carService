<?php
session_start();
include('config.php');
if(strlen($_SESSION['userlogin'])==0)
{
    header('location:index.php');
}
else{
    ?>
    <?php

    include_once("classes/Crud.php");

    $crud = new Crud();


    $query = "SELECT * FROM reservation ORDER BY reservationID DESC";

    $result = $crud->getData($query);

    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">

        <title>Reservation System </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Latest compiled and minified CSS Got off W3 Schools Website  -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>
    <body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">WebSiteName</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active"><a href="welcome.php">Home</a></li>
                <li><a href="customer.php">Customers</a></li>
                <li><a href="cuAdd.html">New Form</a></li>

                <li><a href="driver.php">Drivers</a></li>
                <li><a href="add.html">New Reservations</a></li>
                <li><a href="vehicle.php">Vehicles</a></li>
                <li><a href="cuView.php">View New Customer</></li>
                <li><a href="resExample.php">Res Example</></li>

                <li><a href="customerBootstrap.html">Customer Bootstrap</></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="hero-unit center">
                    <?php
                    // Code for fecthing user full name on the bassis of username or email.
                    $username=$_SESSION['userlogin'];
                    $query=$dbh->prepare("SELECT  FullName FROM userdata WHERE (UserName=:username || UserEmail=:username)");
                    $query->execute(array(':username'=> $username));
                    while($row=$query->fetch(PDO::FETCH_ASSOC)){

                        $username=$row['FullName'];


                    }
                    ?>

                    <h1>Welcome Back <font face="Tahoma" color="red"><?php echo $username;?> ! </font></h1>
                    <br />
                    <p>
                    </p>
                    <a href="logout.php" class="btn btn-large btn-info"><i class="icon-home icon-white"></i> Log me out</a>
                </div>
                <br />

            </div>
            <br />

            <?php

            include_once("classes/Crud.php");

            $crud = new Crud();


            $query = "SELECT * FROM reservation ORDER BY reservationID DESC";

            $result = $crud->getData($query);

            ?>

            <!DOCTYPE html>

            <html lang="en">

            <head>

                <title>Reservation System </title>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <!-- Latest compiled and minified CSS Got off W3 Schools Website  -->
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
                <!-- jQuery library -->
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
                <!-- Latest compiled JavaScript -->
                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>


            </head>

            <body>
            <div class="container">
                <h2 align="center">Reservation System</h2>
                <div><a href="add.html">Add New Data</a><br/><br/><br/>
                    <table class="table table-striped table-hover"  width="86%" >
                        <thead  class="thead-dark" >
                        <tr>
                            <th scope="col">reservationID</th>
                            <th scope="col">Date</th>
                            <th scope="col">Time</th>
                            <th scope="col" >Cust ID</th>
                            <th scope="col" >Passenger First Name</th>
                            <th scope="col" >Passenger Last Name</th>
                            <th scope="col" >Pick Up Address</th>
                            <th scope="col" >Pick up City</th>
                            <th scope="col" >Pick Up State</th>
                            <th scope="col" >Pick Up Zip</th>
                            <th scope="col" >Airline</th>
                            <th scope="col" >Flight Number</th>
                            <th scope="col" >Dept City</th>
                            <th scope="col" >Drop Off Address</th>
                            <th scope="col" >Drop off City</th>
                            <th scope="col" >Drop off State</th>
                            <th scope="col" >Drop off Zip</th>
                            <th scope="col" >Driver Id</th>
                            <th scope="col" >Driver First Name</th>
                            <th scope="col" >Vehicle ID</th>
                            <th scope="col" >Passenger Phone Number</th>
                            <th scope="col" >Passenger Cell Phone</th>
                            <th scope="col" > Edit | Delete</th>

                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <?php
                            foreach ($result as $key => $res)
                            {
                                if ($res['IsVisiable'] != 0) {
                                    echo "<tr>";
                                    echo "<td>" . $res['reservationID'] . "</td>";
                                    echo "<td>" . $res['pDate'] . "</td>";
                                    echo "<td>" . $res['pTime'] . "</td>";
                                    echo "<td>" . $res['CustID'] . "</td>";
                                    echo "<td>" . $res['PassengerFirstName'] . "</td>";
                                    echo "<td>" . $res['PassengerLastName'] . "</td>";
                                    echo "<td>" . $res['PickUpAddress'] . "</td>";
                                    echo "<td>" . $res['pCity'] . "</td>";
                                    echo "<td>" . $res['pState'] . "</td>";
                                    echo "<td>" . $res['pzip'] . "</td>";
                                    echo "<td>" . $res['pAirline'] . "</td>";
                                    echo "<td>" . $res['PFlight'] . "</td>";
                                    echo "<td>" . $res['deptCity'] . "</td>";
                                    echo "<td>" . $res['DropOffAddress'] . "</td>";
                                    echo "<td>" . $res['dCity'] . "</td>";
                                    echo "<td>" . $res['DropOffAddress'] . "</td>";
                                    echo "<td>" . $res['dState'] . "</td>";
                                    echo "<td>" . $res['dzip'] . "</td>";
                                    echo "<td>" . $res['DriverId'] . "</td>";
                                    echo "<td>" . $res['DriverFirstName'] . "</td>";
                                    echo "<td>" . $res['VehicleID'] . "</td>";
                                    echo "<td>" . $res['PassengerPhoneNumber'] . "</td>";
                                    echo "<td>" . $res['cPhone'] . "</td>";
                                    echo "<td><a href=\"edit.php?reservationID=$res[reservationID]\">Edit</a> |
                        <a href=\"delete.php?id=$res[reservationID]\"
                        onClick=\"return confirm('Are you sure you want to delete?')
                        \">Delete</a></td>";
                                }

                            }
                            ?>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <!--    End of Container-->




                <!-- By ConnerT HTML & CSS Enthusiast -->
            </div>
        </div>
    </div>

    <script type="text/javascript">

    </script>
    </body>
    </html>
<?php } ?>
