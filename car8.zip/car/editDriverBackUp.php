<?php
// including the database connection file
include_once ("classes/Crud.php");
$crud = new Crud();
// Getting Id from Url Not sure if this is correct in this application.
$id = $crud->escape_string($_GET['DriverID']);

// reservationID
// selecting data associated with this particular id
// Where does the id come from in the url is this the key for the table ?
/*Uncomment the code bellow and see how the query is done */
/*$query = "SELECT * FROM reservation WHERE id = $id";
echo $query;*/

$result = $crud->getData("SELECT * FROM driver WHERE DriverID=$id");

foreach ($result as $res) {

    $DriverFirstName = $res['DriverFirstName'];
    $DriverLastName = $res['DriverLastName'];
    $DriverPhone = $res['DriverPhone'];
    $DriverEmail = $res['DriverEmail'];

}
?>

<html>
    <head>
        <title>Add Reservation</title>
        <title>Add Driver</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Latest compiled and minified CSS Got off W3 Schools Website  -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>


    </head>
    <body>

    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Reservation System</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active"><a href="welcome.php">Home</a></li>
                <li><a href="#">Page 1</a></li>
                <li><a href="#">Page 2</a></li>
                <li><a href="#">Page 3</a></li>
            </ul>
        </div>
    </nav>



    <form method="post" name="form1" action="editDriveraction.php" >
        <table width="25%" border="0">
            <tr>
                <td>Driver ID</td>
                <td><input type="text" name="DriverID'"  value="<?php echo $id;?>"></td>
            </tr>

            <tr>
                <td>Drivers First Name</td>
                <td><input type="text" name="DriverFirstName" value="<?php echo $DriverFirstName;?>" ></td>
            </tr>

            <tr>
                <td>Drivers Last Name</td>
                <td><input type="text" name="DriverLastName" value="<?php echo $DriverLastName;?>"></td>
            </tr>


            <tr>
                <td>Drivers Phone Number</td>
                <td><input type="text" name="DriverPhone" value="<?php echo $DriverPhone; ?>"></td>
            </tr>

            <tr>
                <td>Drivers Email </td>
                <td><input type="text" name="DriverEmail" value="<?php echo $DriverEmail;?>"></td>
            </tr>

            <tr>
                <td><input type="hidden" name="DriverID" value=<?php echo $_GET['DriverID'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>

    </body>

</html>

