<?php

include_once("classes/Crud.php");

$crud = new Crud();


// This will show the name of the table Name of the table is driver

$query = "SELECT * FROM driver ORDER BY DriverID DESC";

$result = $crud->getData($query);

?>

    <!DOCTYPE html>

    <html lang="en">

    <head>

        <title>Driver </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Latest compiled and minified CSS Got off W3 Schools Website  -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>


    </head>

    <body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">WebSiteName</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active"><a href="welcome.php">Home</a></li>
                <li><a href="customer.php">Customer</a></li>
                <li><a href="addDriver.html"> Add Drivers</a></li>
                <li><a href="add.html">New Reservations</></li>
            </ul>
        </div>
    </nav>
    <div class="container">
        <h2 align="center">Drivers</h2>
     <div><a href="addDriver.html">Add New Driver</a></div>

            <table width="86%" class="table table-bordered">
                <thead>
                <tr>
                    <th>DriverID</th>
                    <th>Driver First Name</th>
                    <th>Driver Last Name</th>
                    <th>Driver Address</th>
                    <th>Driver Email</th>
                    <th>Driver Phone Number</th>

                </tr>
                </thead>
                <tbody>




                <tr>
                    <?php
                    foreach ($result as $key => $res)
                    {
                        if ($res['IsVisiable'] != 0) {
                            echo "<tr>";
                            echo "<td>" . $res['DriverID'] . "</td>";
                            echo "<td>" . $res['DriverFirstName'] . "</td>";
                            echo "<td>" . $res['DriverLastName'] . "</td>";
                            echo "<td>" . $res['DriverPhone'] . "</td>";
                            echo "<td>" . $res['DriverEmail'] . "</td>";

                            echo "<td><a href=\"editDriver.php?DriverID=$res[DriverID]\">Edit Driver</a> |
                        <a href=\"deleteDriver.php?id=$res[DriverID]\"
                        onClick=\"return confirm('Are you sure you want to delete?')
                        \">Delete</a></td>";
                        }
                    }
                    ?>
                </tr>
                </tbody>
            </table>
        </div>
        <!--    End of Container-->

    </body>

    </html>
<?php
