<?php
session_start();
include('config.php');
if(strlen($_SESSION['userlogin'])==0)
{
    header('location:index.php');
}
else{
    ?>
    <?php

    include_once("classes/Crud.php");

    $crud = new Crud();


    $query = "SELECT * FROM cu ORDER BY c_ID DESC";

    $result = $crud->getData($query);

    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">

        <title>Reservation System </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Latest compiled and minified CSS Got off W3 Schools Website  -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>
    <body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">WebSiteName</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active"><a href="welcome.php">Home</a></li>
                <li><a href="customer.php">Customers</a></li>
                <li><a href="driver.php">Drivers</a></li>
                <li><a href="add.html">New Reservations</a></li>
                <li><a href="vehicle.php">Vehicles</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="hero-unit center">
                    <?php
                    // Code for fecthing user full name on the bassis of username or email.
                    $username=$_SESSION['userlogin'];
                    $query=$dbh->prepare("SELECT  FullName FROM userdata WHERE (UserName=:username || UserEmail=:username)");
                    $query->execute(array(':username'=> $username));
                    while($row=$query->fetch(PDO::FETCH_ASSOC)){

                        $username=$row['FullName'];


                    }
                    ?>

                    <h1>Welcome Back <font face="Tahoma" color="red"><?php echo $username;?> ! </font></h1>
                    <br />
                    <p>
                    </p>
                    <a href="logout.php" class="btn btn-large btn-info"><i class="icon-home icon-white"></i> Log me out</a>
                </div>
                <br />

            </div>
            <br />

            <?php

            include_once("classes/Crud.php");

            $crud = new Crud();


            $query = "SELECT * FROM res ORDER BY c_ID DESC";

            $result = $crud->getData($query);

            ?>

            <!DOCTYPE html>

            <html lang="en">

            <head>

                <title>Reservation System </title>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <!-- Latest compiled and minified CSS Got off W3 Schools Website  -->
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
                <!-- jQuery library -->
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
                <!-- Latest compiled JavaScript -->
                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>


            </head>

            <body>
            <div class="container">
                <h2 align="center">Reservation System</h2>
                <div><a href="add.html">Add New Data</a><br/><br/><br/>
                    <table width="86%" class="table table-bordered">
                        <thead>
                        <tr>
                            <th>CustomerID</th>
                            <th>FirstName</th>
                            <th>LastName</th>



                            <th>	Edit | Delete</th>

                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <?php
                            foreach ($result as $key => $res)
                            {
                                if ($res['IsVisiable'] != 0) {
                                    echo "<tr>";
                                    echo "<td>" . $res['c_ID'] . "</td>";
                                    echo "<td>" . $res['c_FirstName'] . "</td>";
                                    echo "<td>" . $res['c_LastName'] . "</td>";

                                    echo "<td><a href=\"edit.php?reservationID=$res[reservationID]\">Edit</a> |
                        <a href=\"delete.php?id=$res[reservationID]\"
                        onClick=\"return confirm('Are you sure you want to delete?')
                        \">Delete</a></td>";
                                }

                            }
                            ?>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <!--    End of Container-->




                <!-- By ConnerT HTML & CSS Enthusiast -->
            </div>
        </div>
    </div>

    <script type="text/javascript">

    </script>
    </body>
    </html>
<?php } ?>