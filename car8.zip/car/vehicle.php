<?php

include_once("classes/Crud.php");

$crud = new Crud();


// This will show the name of the table Name of the table is driver

$query = "SELECT * FROM vehicle ORDER BY VehicleID DESC";

$result = $crud->getData($query);


?>

    <!DOCTYPE html>

    <html lang="en">

    <head>

        <title>Vehicle </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Latest compiled and minified CSS Got off W3 Schools Website  -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">WebSiteName</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active"><a href="welcome.php">Home</a></li>
                <li><a href="customer.php">Customers</a></li>
                <li><a href="driver.php">Drivers</a></li>
                <li><a href="add.html">New Reservations</a></li>
                <li><a href="vehicle.php">Vehicles</a></li>
            </ul>
        </div>
    </nav>



    <body>
    <div class="container">
        <h2 align="center">Reservation System</h2>
        <h3>Garage</h3>
        <div><a href="addVehicle.html">See Garage</a><br/><br/><br/>
            <table width="86%" class="table table-bordered">
                <thead>
                <tr>
                    <th> licensePlate</th>
                    <th>Make</th>
                    <th>Model</th>
                    <th>Model</th>
                    <th>Color</th>
                    <th>Seats</th>


                </tr>
                </thead>
                <tbody>

                <tr>
                    <?php
                    foreach ($result as $key => $res)
                    {
                        if ($res['IsVisiable'] != 0) {
                            echo "<tr>";
                            echo "<td>" . $res['VehicleID'] . "</td>";
                            echo "<td>" . $res['licensePlate'] . "</td>";
                            echo "<td>" . $res['Make'] . "</td>";
                            echo "<td>" . $res['Model'] . "</td>";
                            echo "<td>" . $res['Color'] . "</td>";
                            echo "<td>" . $res['Seats'] . "</td>";

                            echo "<td><a href=\"editDriver.php?DriverID=$res[VehicleID]\">Edit Driver</a> |
                        <a href=\"deleteVehicle.php?id=$res[VehicleID]\"
                        onClick=\"return confirm('Are you sure you want to delete?')
                        \">Delete</a></td>";
                        }
                    }
                    ?>
                </tr>
                </tbody>
            </table>
        </div>
        <!--    End of Container-->
    </div>
    </body>

    </html>
<?php
