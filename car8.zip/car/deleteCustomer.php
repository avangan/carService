<?php
// including the database connection file

include_once("classes/Crud.php");

$crud = new Crud();

$id = $crud->escape_string($_GET['id']);

// deleting the  from the table Do not Delete instead move into a new table

$result =  $crud-> execute ("Update customer SET IsVisiable=0 WHERE CustID= $id");


header("Location:index.php");


?>
