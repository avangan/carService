<?php
session_start();
include('config.php');
if(strlen($_SESSION['userlogin'])==0)
{
    header('location:index.php');
}
else {

    include_once("classes/Crud.php");

    $crud = new Crud();

    $DriverTable = "SELECT * FROM driver";

    $DriverResult = $crud->getData($DriverTable);

/*    DriverID
DriverFirstName
DriverLastName
DriverPhone
DriverEmail*/



    ?>
    <select>
        <?php
        foreach ($DriverResult as $key => $row) {
            ?>
            <option value="<?php echo $row['DriverFirstName']; ?>"><?php echo $row['DriverLastName'] . " " . $row['Model']; ?></option>
            <?php
        }
        ?>
    </select>
    <?php



    $query = "SELECT * FROM vehicle";

    $result = $crud->getData($query);



    ?>
    <select>
        <?php
        foreach ($result as $key => $row) {
            ?>
            <option value="<?php echo $row['VehicleID']; ?>"><?php echo $row['Make'] . " " . $row['Model']; ?></option>
            <?php
        }
        ?>
    </select>
    <?php
}
?>


