<?php
// including the database connection file

include_once("classes/Crud.php");
include_once ("classes/Validation.php");


$crud = new Crud();
$validation = new Validation();

if(isset($_POST['update']))

{

     $DriverID= $crud->escape_string($_POST['DriverID']);

    $DriverFirstName= $crud->escape_string($_POST['DriverFirstName']);

    $DriverLastName= $crud->escape_string($_POST['DriverLastName']);

    $DriverPhone= $crud->escape_string($_POST['DriverPhone']);

    $DriverEmail= $crud->escape_string($_POST['DriverEmail']);


    $msg = $validation->check_empty($_POST, array('DriverID', 'DriverFirstName', 'DriverLastName', 'DriverPhone', 'DriverEmail'));

    if($msg) {
        echo $msg;
        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
    }
    else{
        $result =$crud->execute("UPDATE driver SET DriverFirstName='$DriverFirstName', DriverLastName='$DriverLastName', DriverPhone='$DriverPhone', DriverEmail='$DriverEmail' WHERE DriverID=$DriverID");

        header("Location: index.php");
    }
}
?>