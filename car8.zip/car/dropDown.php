<?php
// including the database connection file

include_once ("classes/Crud.php");

$crud = new Crud();

// Getting Id from Url

$id = $crud->escape_string($_GET['reservationID']);

$Custid = $crud->escape_string($_GET['CustID']);

// reservationID
// selecting data associated with this particular id

// Where does the id come from in the url is this the key for the table ?
/*Uncomment the code bellow and see how the query is done */
/*$query = "SELECT * FROM reservation WHERE id = $id";
echo $query;*/

$result = $crud->getData("SELECT * FROM reservation WHERE reservationid = $id")

$CustResult =  $crud->getData("SELECT * FROM  customer WHERE CustID = $id")



foreach ($result as $res) {

    $Date = $res['Date'];
    $Time = $res['Time'];
    $CustID = $res['CustID'];
    $PassengerFirstName = $res['PassengerFirstName'];
    $PassengerLastName= $res['PassengerLastName'];
    $PickUpAddress = $res['PickUpAddress'];
    $DropOffAddress = $res['DropOffAddress'];
    $DriverId = $res['DriverId'];
    $DriverFirstName = $res['DriverFirstName'];
    $VehicleID = $res['VehicleID'];
    $PassengerPhoneNumber = $res['PassengerPhoneNumber'];
}
?>

<htm>
    <head>
        <title>Edit Data</title>

    </head>
    <body>
    <a href="index.php">Home</a>
    <br/><br/>
    <div id="msg" </div>

    <form method="post" name="form1" action="editaction.php" >
        <table width="25%" border="0">
            <tr>
                <td>Reservation ID</td>
                <td><input type="text" name="reservationID"  value="<?php echo $id;?>"></td>
            </tr>
            <tr>
                <td>Date</td>
                <td><input type="text" name="Date" value="<?php echo $Date;?>"></td>
            </tr>
            <tr>
                <td>Time</td>
                <td><input type="text" name="Time" value="<?php echo  $Time;?>"></td>
            </tr>
            <tr>
                <td>CustID</td>
                <td><input type="text" name="CustID" value="<?php echo $CustID;?>"></td>
            </tr>

            <tr>
                <td>Passenger First Name </td>
                <td><input type="text" name="PassengerFirstName" value="<?php echo $PassengerFirstName;?>"></td>
            </tr>

            <tr>
                <td>Passenger Last Name </td>
                <td><input type="text" name="PassengerLastName" value="<?php echo $PassengerLastName;?>"></td>
            </tr>

            <tr>
                <td>Pick up address </td>
                <td><input type="text" name="PickUpAddress" value="<?php echo $PickUpAddress;?>"></td>
            </tr>

            <tr>
                <td>Drop off address </td>
                <td><input type="text" name="DropOffAddress" value="<?php echo $DropOffAddress;?>"></td>
            </tr>

            <tr>
                <td>Driver Id  </td>
                <td><input type="text" name="DriverId" value="<?php echo $DriverId;?>"></td>
            </tr>
            <tr>
                <td>Driver First Name </td>
                <td><input type="text" name="DriverFirstName" value="<?php echo $DriverFirstName;?>" ></td>
            </tr>

            <tr>
                <td>Vehicle ID </td>
                <td><input type="text" name="VehicleID" value="<?php echo $VehicleID;?>"></td>
            </tr>

            <tr>
                <td>Passenger Phone Number </td>
                <td><input type="text" name="PassengerPhoneNumber" value="<?php echo $PassengerPhoneNumber;?>"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="submit" value="Add" </td>
            </tr>
            <tr>
                <td><input type="hidden" name="reservationID" value=<?php echo $_GET['reservationID'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>

    </body>

</htm>
