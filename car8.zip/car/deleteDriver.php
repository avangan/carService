<?php
// including the database connection file

include_once("classes/Crud.php");

$crud = new Crud();

$id = $crud->escape_string($_GET['id']);

// deleting the  from the table Do not Delete instead move into a new table

$result =  $crud-> execute ("Update driver SET IsVisiable=0 WHERE DriverID= $id");


header("Location:index.php");


?>