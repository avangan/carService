


<?php
// including the database connection file

include_once ("classes/Crud.php");

$crud = new Crud();

// Getting Id from Url

$id = $crud->escape_string($_GET['CustID']);

// reservationID
// selecting data associated with this particular id

// Where does the id come from in the url is this the key for the table ?
/*Uncomment the code bellow and see how the query is done */
/*$query = "SELECT * FROM reservation WHERE id = $id";
echo $query;*/

$result = $crud->getData("SELECT * FROM customer WHERE CustID = $id");





foreach ($result as $res) {


    $CustID = $res['CustID'];
    $CustFirstName = $res['CustFirstName'];
    $CustLastName = $res['CustLastName'];
    $CustPhoneNumber = $res['CustPhoneNumber'];
    $CustEmail = $res['CustEmail'];

}
?>

<html>
<head>
    <title>Customer</title>
    <meta charset="utf-8">

    <title>Reservation System </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Latest compiled and minified CSS Got off W3 Schools Website  -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">WebSiteName</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="welcome.php">Home</a></li>
            <li><a href="customer.php">Customers</a></li>
            <li><a href="cuAdd.html">New Form</a></li>
            <li><a href="driver.php">Drivers</a></li>
            <li><a href="add.html">New Reservations</a></li>
            <li><a href="vehicle.php">Vehicles</a></li>
        </ul>
    </div>
</nav>
<body>



<div class="container">

    <div class="row">
        <div class="col text-center">
            <h2 >Add Customer</h2>
        </div>

        <form  action="editActionCustomer.php" method="post" name="form1" >
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputAddress">Customer ID</label>
                    <input type="text" class="form-control"  name="CustID"  value="<?php echo  $CustID;?>" >
                </div>
                <div class="form-group col-md-6">
                    <label>Customer First Name </label>
                    <input type="text" class="form-control" name="CustFirstName" value="<?php echo $CustFirstName;?>">
                </div>

                <div class="form-group col-md-6">
                    <label>Customer Last Name </label>
                    <input type="text" class="form-control"  placeholder="Last Name" name="CustLastName" value="<?php echo $CustLastName;?>">
                </div>
                <div class="form-group col-md-6">
                    <label>Customer Phone Number</label>

                    <input type="text" class="form-control" name="CustPhoneNumber" value="<?php echo $CustPhoneNumber ;?>">
                </div>

                <div class="form-group col-md-12">
                    <label for="inputAddress">Email</label>
                    <input type="text" class="form-control"  placeholder="Email" name="CustEmail" value="<?php echo  $CustEmail;?>">
                </div>
<!--
                <div class="form-group col-md-6">
                    <label for="inputAddress">City</label>
                    <input type="text" class="form-control" name="HCity">
                </div>
                <div class="form-group col-md-3">
                    <label  >State </label>
                    <input type="text" class="form-control" placeholder="State" name="Hstate" >
                </div>

                <div class="form-group col-md-3">
                    <label> Zip </label>
                    <input type="text" class="form-control"  placeholder="Zip" name="HZip" >
                </div>-->
            </div>


    </div>

    <div class="row">
        <div class="col text-center">
            <button type="submit" name="update" class="btn btn-primary" value="Update">Submit</button>
        </div>
    </div>

    </form>
</div>


</body>

</html>
