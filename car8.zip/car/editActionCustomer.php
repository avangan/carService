<?php
// including the database connection file

include_once("classes/Crud.php");
include_once ("classes/Validation.php");


$crud = new Crud();
$validation = new Validation();


if(isset($_POST['update']))

{
    $CustID= $crud->escape_string($_POST['CustID']);

    $CustFirstName = $crud->escape_string($_POST['CustFirstName']);

    $CustLastName =$crud->escape_string($_POST['CustLastName']);

    $CustPhoneNumber = $crud->escape_string($_POST['CustPhoneNumber']);


    $CustEmail = $crud->escape_string($_POST['CustEmail']);

/*    $Address = $crud->escape_string($_POST['Address']);

    $HCity = $crud->escape_string($_POST['HCity']);

    $Hstate = $crud->escape_string($_POST['Hstate']);

    $HZip = $crud->escape_string($_POST['HZip']);*/


    $msg = $validation->check_empty($_POST, array('CustID', 'CustFirstName', 'CustLastName', 'CustPhoneNumber', 'CustEmail'));

/*    The Code below could be slightly wrong from the bottom down.
    $msg = $validation->check_empty($_POST, array('CustID', 'CustFirstName', 'CustLastName', 'CustPhoneNumber', 'CustEmail','Address', 'HCity','Hstate','HZip'));*/

    if($msg) {
        echo $msg;
        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
    }
    else{
        $result =$crud->execute("UPDATE customer SET CustFirstName='$CustFirstName', CustLastName='$CustLastName', CustPhoneNumber='$CustPhoneNumber', CustEmail='$CustEmail' WHERE CustID= $CustID");

/*       The Code from Email on could be wrong
        $result =$crud->execute("UPDATE customer SET CustFirstName='$CustFirstName', CustLastName='$CustLastName', CustPhoneNumber='$CustPhoneNumber', CustEmail='$CustEmail', Address='$Address', HCity='$HCity', Hstate='$Hstate' HZip='$HZip' WHERE CustID= $CustID");*/
        header("Location: index.php");
    }
}
?>