<?php
session_start();
include('config.php');
if(strlen($_SESSION['userlogin'])==0)
{
    header('location:index.php');
}
else{
    ?>
    <?php

    include_once("classes/Crud.php");

    $crud = new Crud();


    $query = "SELECT * FROM customer ORDER BY CustID DESC";

    $result = $crud->getData($query);

    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">

        <title>Reservation System </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Latest compiled and minified CSS Got off W3 Schools Website  -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>
    <body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">WebSiteName</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active"><a href="welcome.php">Home</a></li>
                <li><a href="customer.html">Add New Customer</a></li>
                <li><a href="cuAdd.html">New Form</a></li>
                <li><a href="driver.php">Drivers</a></li>
                <li><a href="add.html">New Reservations</></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="row">
            <div class="span12">
                <div class="hero-unit center">
                    <?php
                    // Code for fecthing user full name on the bassis of username or email.
                    $username=$_SESSION['userlogin'];
                    $query=$dbh->prepare("SELECT  FullName FROM userdata WHERE (UserName=:username || UserEmail=:username)");
                    $query->execute(array(':username'=> $username));
                    while($row=$query->fetch(PDO::FETCH_ASSOC)){

                        $username=$row['FullName'];


                    }
                    ?>

                    <h1>Welcome Back <font face="Tahoma" color="red"><?php echo $username;?> ! </font></h1>
                    <br />
                    <p>
                    </p>
                    <a href="logout.php" class="btn btn-large btn-info"><i class="icon-home icon-white"></i> Log me out</a>
                </div>
                <br />

            </div>
            <br />





            <?php

            include_once("classes/Crud.php");

            $crud = new Crud();


            $query = "SELECT * FROM cu ORDER BY c_ID DESC";


            $result = $crud->getData($query);

            ?>

            <!DOCTYPE html>

            <html lang="en">

            <head>

                <title>Customer Reservation System  </title>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <!-- Latest compiled and minified CSS Got off W3 Schools Website  -->
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
                <!-- jQuery library -->
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
                <!-- Latest compiled JavaScript -->
                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>


            </head>

            <body>
            <div class="container">
                <h2 align="center">Customers </h2>

                <table width="86%" class="table table-bordered">
                    <thead>
                    <tr>
                        <th> Customer First Name</th>

                        <th>Customer Last Name</th>

                        <th>AccountType</th>

                        <th>Company</th>

                        <th>AstFirstName</th>

                        <th>AstLastName</th>

                        <th>Ast_PhoneWork</th>

                        <th>Ast_PhoneWork</th>

                        <th>Ast_cellPhonePersonal</th>

                        <th>Ast_emailOne</th>

                        <th>Ast_emailTwo </th>

                        <th> BusinessAddress</th>

                        <th>Bunit </th>

                        <th>BCity</th>

                        <th>Bstate</th>

                        <th>BZip </th>

                        <th>HomeAddress</th>

                        <th> Unit </th>

                        <th> City </th>

                        <th>Hstate </th>

                        <th> Zip</th>

                        <th> InternalNotes</th>

                        <th>c_OfficePhone </th>

                        <th>c_HomePhone </th>

                        <th>c_Emergency</th>

                        <th>c_CellPhoneOnePersonal</th>

                        <th>c_CellPhoneTwoEmergency </th>

                        <th>c_cellPhoneThreeAst </th>

                        <th>c_emailOne</th>

                        <th>C_emailTwo </th>

                        <th> C_emailThree </th>

                        <th> Delete</th>
                        <th> Delete</th>
                        <th> Delete</th>
                        <th> Delete</th>
                        <th> Delete</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <?php
                        foreach ($result as $key => $res)
                        {
                            if ($res['IsVisiable'] != 0) {


                                echo "<tr>";
                                echo "<td>" . $res['c_ID'] . "</td>";
                                echo "<td>" . $res['c_FirstName'] . "</td>";
                                echo "<td>" . $res['c_LastName'] . "</td>";
                                echo "<td>" . $res['AccountType'] . "</td>";
                                echo "<td>" . $res['Company'] . "</td>";
                                echo "<td>" . $res['AstFirstName'] . "</td>";
                                echo "<td>" . $res['AstLastName'] . "</td>";
                                echo "<td>" . $res['Ast_PhoneWork'] . "</td>";
                                echo "<td>" . $res['Ast_CellPhoneWork'] . "</td>";
                                echo "<td>" . $res['Ast_cellPhonePersonal'] . "</td>";
                                echo "<td>" . $res['Ast_emailOne'] . "</td>";
                                echo "<td>" . $res['Ast_emailTwo'] . "</td>";
                                echo "<td>" . $res['BusinessAddress'] . "</td>";
                                echo "<td>" . $res['Bunit'] . "</td>";
                                echo "<td>" . $res['BCity'] . "</td>";
                                echo "<td>" . $res['Bstate'] . "</td>";
                                echo "<td>" . $res['BZip'] . "</td>";
                                echo "<td>" . $res['HomeAddress'] . "</td>";
                                echo "<td>" . $res['Unit'] . "</td>";
                                echo "<td>" . $res['HCity'] . "</td>";
                                echo "<td>" . $res['Hstate'] . "</td>";
                                echo "<td>" . $res['HZip'] . "</td>";
                                echo "<td>" . $res['InternalNotes'] . "</td>";
                                echo "<td>" . $res['c_OfficePhone'] . "</td>";
                                echo "<td>" . $res['c_HomePhone'] . "</td>";
                                echo "<td>" . $res['c_Emergency'] . "</td>";
                                echo "<td>" . $res['c_CellPhoneOnePersonal'] . "</td>";
                                echo "<td>" . $res['c_CellPhoneTwoEmergency'] . "</td>";
                                echo "<td>" . $res['c_cellPhoneThreeAst'] . "</td>";
                                echo "<td>" . $res['c_emailOne'] . "</td>";
                                echo "<td>" . $res['C_emailTwo'] . "</td>";
                                echo "<td>" . $res['C_emailThree'] . "</td>";


                            }

                            echo "<td><a href=\"editCustomer.php?c_ID=$res[c_ID]\">Edit</a> |
                <a href=\"deleteCustomer.php?id=$res[c_ID]\"
                   onClick=\"return confirm('Are you sure you want to delete?')
                \">Delete</a></td>";
                            echo "<td><a href=\"add.php?c_ID=$res[c_ID]\">New Reservations</a></td>";


                        }
                        ?>
                    </tr>
                    </tbody>
                </table>
            </div>
            <!--    End of Container-->





            <!-- By ConnerT HTML & CSS Enthusiast -->
        </div>
    </div>
    </div>

    <script type="text/javascript">

    </script>
    </body>
    </html>
<?php } ?>
