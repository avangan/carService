<?php
include('config.php');
include_once("classes/Crud.php");
$crud = new Crud();
$queryVehicle = "SELECT * FROM vehicle";
$resultVeh = $crud->getData($queryVehicle);
?>

    <select>
        <?php
        foreach ($resultVeh as $key => $row) {
            ?>
            <option value="<?php echo $row['VehicleID']; ?>"><?php echo $row['Make'] . " " . $row['Model']; ?></option>
            <?php } ?>
    </select>

