<?php
// including the database connection file

include_once("classes/Crud.php");
include_once ("classes/Validation.php");


$crud = new Crud();
$validation = new Validation();


if(isset($_POST['update']))

{
    $CustID= $crud->escape_string($_POST['CustID']);

    $CustFirstName = $crud->escape_string($_POST['CustFirstName']);

    $CustLastName =$crud->escape_string($_POST['CustLastName']);

    $CustPhoneNumber = $crud->escape_string($_POST['CustPhoneNumber']);


    $CustEmail = $crud->escape_string($_POST['CustEmail']);



    $msg = $validation->check_empty($_POST, array('CustID', 'CustFirstName', 'CustLastName', 'CustPhoneNumber', 'CustEmail'));

    if($msg) {
        echo $msg;
        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
    }
    else{
        $result =$crud->execute("UPDATE customer SET CustFirstName='$CustFirstName', CustLastName='$CustLastName', CustPhoneNumber='$CustPhoneNumber', CustEmail=' $CustEmail' WHERE CustID= $CustID");

        header("Location: index.php");
    }
}
?>