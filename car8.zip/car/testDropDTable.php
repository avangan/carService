<?php
include('config.php');
include_once("classes/Crud.php");
$crud = new Crud();
$queryVehicle = "SELECT * FROM vehicle";
$resultVeh = $crud->getData($queryVehicle);
?>





<html>
<form action="welcome.php" method="post" name="form1">
    <table width="25%" border="0">


        <tr>
            <td>Time</td>
            <td><input type="text" value  name="This Row Works "></td>
        </tr>




            <tr>
            <td>Need a Drop Down Box in this Row</td>
                <td>

                    <select>
                        <?php
                        foreach ($resultVeh as $key => $row) {
                            ?>
                            <option value="<?php echo $row['VehicleID']; ?>"><?php echo $row['Make'] . " " . $row['Model']; ?> name"test"</option>
                        <?php } ?>
                    </select>


                </td>



    </table>
</form>
</body>
</html>







