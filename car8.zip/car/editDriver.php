<?php
// including the database connection file
include_once ("classes/Crud.php");
$crud = new Crud();
// Getting Id from Url Not sure if this is correct in this application.
$id = $crud->escape_string($_GET['DriverID']);

// reservationID
// selecting data associated with this particular id
// Where does the id come from in the url is this the key for the table ?
/*Uncomment the code bellow and see how the query is done */
/*$query = "SELECT * FROM reservation WHERE id = $id";
echo $query;*/

$result = $crud->getData("SELECT * FROM driver WHERE DriverID=$id");

foreach ($result as $res) {

/*    $DriverID = $res['DriverID'];*/
    $DriverFirstName = $res['DriverFirstName'];
    $DriverLastName = $res['DriverLastName'];
    $DriverPhone = $res['DriverPhone'];
    $DriverEmail = $res['DriverEmail'];

}
?>

<html>
<head>
    <title>Add Reservation</title>
    <title>Add Driver</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Latest compiled and minified CSS Got off W3 Schools Website  -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>


</head>


<body>


<div class="container">

    <div class="row">
        <div class="col text-center">
            <h2 >Edit Driver </h2>
        </div>

        <form method="post" name="form1" action="editDriveraction.php" >


            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputAddress">Driver ID</label>
                    <input type="text" class="form-control"  name="DriverID'"  value="<?php echo $id;?>">
                </div>
                <div class="form-group col-md-6">
                    <label>Driver First Name </label>
                    <input type="text" class="form-control"  name="DriverFirstName" value="<?php echo $DriverFirstName;?>" >
                </div>

                <div class="form-group col-md-6">
                    <label>Driver Last Name </label>
                    <input type="text" class="form-control"  placeholder="Last Name"  name="DriverLastName" value="<?php echo $DriverLastName;?>">
                </div>
                <div class="form-group col-md-6">
                    <label>Driver Phone Number</label>
                    <input type="text" class="form-control" name="DriverPhone" value="<?php echo $DriverPhone;?>">
                </div>

                <div class="form-group col-md-12">
                    <label for="inputAddress">Driver Email</label>
                    <input type="text" class="form-control"  placeholder="Email" name="DriverEmail" value="<?php echo $DriverEmail;?>">
                </div>

            </div>

    </div>

    <div>
        <tr>
            <td><input type="hidden" name="DriverID" value=<?php echo $_GET['DriverID'];?>></td>
            <td><input type="submit" name="update" value="Update"></td>
        </tr>

    </div>
<!--
    <div class="row">
        <div class="col text-center">
            <button type="submit" name="update" class="btn btn-primary" value="Update">Submit</button>
        </div>
    </div>-->

    </form>
</div>


</body>

</html>
