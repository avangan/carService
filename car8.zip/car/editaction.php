<?php
// including the database connection file

include_once("classes/Crud.php");
include_once ("classes/Validation.php");


$crud = new Crud();
$validation = new Validation();


if(isset($_POST['update']))

{

    $reservationID= $crud->escape_string($_POST['reservationID']);

    $pDate = $crud->escape_string(($_POST['pDate']));
    $pTime = $crud->escape_string(($_POST['pTime']));
    $CustID = $crud->escape_string(($_POST['CustID']));
    $PassengerFirstName = $crud->escape_string(($_POST['PassengerFirstName']));
    $PassengerLastName = $crud->escape_string(($_POST['PassengerLastName']));
    $PickUpAddress = $crud->escape_string(($_POST['PickUpAddress']));
    $pCity = $crud->escape_string(($_POST['pCity']));
    $pState = $crud->escape_string(($_POST['pState']));
    $pzip = $crud->escape_string(($_POST['pzip']));
    $pAirline = $crud->escape_string(($_POST['pAirline']));
    $PFlight = $crud->escape_string(($_POST['PFlight']));
    $deptCity = $crud->escape_string(($_POST['deptCity']));
    $DropOffAddress = $crud->escape_string(($_POST['DropOffAddress']));
    $dCity = $crud->escape_string(($_POST['dCity']));
    $dState = $crud->escape_string(($_POST['dState']));
    $dzip= $crud->escape_string(($_POST['dzip']));
    $DriverId = $crud->escape_string(($_POST['DriverId']));
    $DriverFirstName = $crud->escape_string(($_POST['DriverFirstName']));
    $VehicleID = $crud->escape_string(($_POST['VehicleID']));
    $PassengerPhoneNumber = $crud->escape_string(($_POST['PassengerPhoneNumber']));
    $cPhone = $crud->escape_string(($_POST['cPhone']));




    $msg = $validation->check_empty($_POST, array('reservationID','pDate','pTime','CustID','PassengerFirstName','PassengerLastName','PickUpAddress','pCity','pState','pzip','pAirline','PFlight','deptCity','DropOffAddress','dCity','dState','dzip','DriverId','DriverFirstName','VehicleID','PassengerPhoneNumber','cPhone'));
    if($msg) {
        echo $msg;
        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
    }
else{

    $result =$crud->execute("UPDATE reservation SET pDate='$pDate', pTime='$pTime', CustID='$CustID', PassengerFirstName='$PassengerFirstName' , PassengerLastName='$PassengerLastName' , PickUpAddress='$PickUpAddress', pCity='$pCity', pState='$pState', pzip='$dzip' , pAirline='$pAirline' , PFlight='$PFlight' , deptCity='$deptCity' , DropOffAddress='$DropOffAddress' , dCity='$dCity' , dState='$dState' , dzip='$dzip' , DriverId='$DriverId', DriverFirstName='$DriverFirstName' , VehicleID='$VehicleID' , PassengerPhoneNumber='$PassengerPhoneNumber', cPhone='$cPhone' WHERE reservationID= $reservationID");
    header("Location: index.php");
    }
}
?>