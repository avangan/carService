<?php
// including the database connection file

include_once ("classes/Crud.php");

$crud = new Crud();

// Getting Id from Url

$id = $crud->escape_string($_GET['reservationID']);

// reservationID
// selecting data associated with this particular id

// Where does the id come from in the url is this the key for the table ?
/*Uncomment the code bellow and see how the query is done */
/*$query = "SELECT * FROM reservation WHERE id = $id";
echo $query;*/

$result = $crud->getData("SELECT * FROM reservation WHERE reservationid = $id");

foreach ($result as $res) {

    $pDate = $res['pDate'];
    $pTime = $res['pTime'];
    $CustID = $res['CustID'];
    $PassengerFirstName = $res['PassengerFirstName'];
    $PassengerLastName = $res['PassengerLastName'];
    $PickUpAddress = $res['PickUpAddress'];
    $pCity = $res['pCity'];
    $pState = $res['pState'];
    $pzip = $res['pzip'];
    $pAirline = $res['pAirline'];
    $PFlight = $res['PFlight'];
    $deptCity = $res['deptCity'];
    $DropOffAddress = $res['DropOffAddress'];
    $dCity = $res['dCity'];
    $dState = $res['dState'];
    $dzip= $res['dzip'];
    $DriverId = $res['DriverId'];
    $DriverFirstName = $res['DriverFirstName'];
    $VehicleID = $res['VehicleID'];
    $PassengerPhoneNumber = $res['PassengerPhoneNumber'];
    $cPhone = $res['cPhone'];


}
?>

<htm>
    <head>
        <title>Edit Data</title>

    </head>
    <body>
    <a href="welcome.php">Home</a>
    <br/><br/>
    <div id="msg" </div>

    <form method="post" name="form1" action="editaction.php" >
        <table width="25%" border="0">




            <tr>
                <td>Reservation ID</td>
                <td><input type="text" name="reservationID"  value="<?php echo $id;?>"></td>
            </tr>

            <tr>
                <td>Date</td>


                <td><input type="text" name="pDate"  value="<?php echo $pDate;?>"></td>

            </tr>
            <tr>
                <td>Time</td>

                <td><input type="text" name="pTime"  value="<?php echo $pTime ;?>"></td>

            </tr>
            <tr>
                <td>CustID</td>

                <td><input type="text" name="CustID"  value="<?php echo $CustID;?>"></td>

         <!--   This is for passing in the customerId and Disabling int   -->
           <!--     <td><input type="text" name="CustID" value="<?php /*echo  $CustID;*/?>" disabled></td>-->

            </tr>
            <tr>
                <td>Passenger First Name </td>
                <td><input type="text" name="PassengerFirstName"  value="<?php echo $PassengerFirstName;?>"></td>
            </tr>

            <tr>

                <td>Passenger Last Name </td>
                <td><input type="text" name="PassengerLastName"  value="<?php echo $PassengerLastName;?>"></td>
            </tr>

            <tr>
                <td>Passenger Phone Number </td>
                <td><input type="text" name="PassengerPhoneNumber"  value="<?php echo $PassengerPhoneNumber;?>"></td>
            </tr>
            <tr>
            <tr>
                <td>Passenger cell Phone Number </td>
                <td><input type="text" name="cPhone"  value="<?php echo $cPhone;?>"></td>
            </tr>
            <tr>

            <tr>
                <td>Pick up address </td>
                <td><input type="text" name="PickUpAddress"  value="<?php echo $PickUpAddress;?>"></td>
            </tr>

            <tr>
                <td>Pick up City </td>
                <td><input type="text" name="pCity"  value="<?php echo $pCity;?>"></td>
            </tr>

            <tr>
                <td>Pick up State </td>
                <td><input type="text" name="pState"  value="<?php echo $pState;?>"></td>
            </tr>

            <tr>
                <td>Pick up Zip </td>
                <td><input type="text" name="pzip"  value="<?php echo $pzip;?>"></td>
            </tr>

            <tr>
                <td>Airline </td>
                <td><input type="text" name="pAirline"  value="<?php echo $pAirline;?>"></td>
            </tr>

            <tr>
                <td>Flight Number </td>
                <td><input type="text" name="PFlight"  value="<?php echo $PFlight;?>"></td>
            </tr>

            <tr>
                <td>Departing City </td>
                <td><input type="text" name="deptCity"  value="<?php echo $deptCity;?>"></td>
            </tr>

            <tr>
                <td>Drop off address </td>
                <td><input type="text" name="DropOffAddress"  value="<?php echo $DropOffAddress;?>"></td>
            </tr>

            <tr>
                <td>Drop City </td>
                <td><input type="text" name="dCity"  value="<?php echo $dCity;?>"></td>
            </tr>


            <tr>
                <td>Drop off State </td>
                <td><input type="text" name="dState"  value="<?php echo $dState;?>"></td>
            </tr>

            <tr>
                <td>Drop off Zip </td>
                <td><input type="text" name="dzip"  value="<?php echo $dzip;?>"></td>
            </tr>            <tr>

                <td>Driver Id  </td>
                <td><input type="text" name="DriverId"  value="<?php echo $DriverId;?>"></td>
            </tr>
            <tr>
                <td>Driver First Name </td>
                <td><input type="text" name="DriverFirstName"  value="<?php echo $DriverFirstName;?>"></td>
            </tr>

            <tr>
                <td>Vehicle ID </td>

                <td><input type="text" name="VehicleID"  value="<?php echo $VehicleID;?>"></td>

            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="submit" value="Add" </td>
            </tr>
            <tr>
                <td><input type="hidden" name="reservationID" value=<?php echo $_GET['reservationID'];?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>
        </table>
    </form>

    </body>

</htm>
